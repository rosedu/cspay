
//////menu

<div id="menu">
		<ul>
			<li  class="active"><a href="#">Home</a></li>
			<li><a href="#">Despre</a></li>
			<li><a href="#">Modifica</a></li>
			<li><a href="#">Log Out </a></li>
			<li><a href="#">Contact </a></li>
		</ul>
</div>

////submenu

<div id="submenu">
		<ul>
			<li class="subactive"><a href="#">adauga</a></li>
			<li><a href="#">sterge</a></li>
			<li><a href="#">Modifica</a></li>
			<li><a href="#">printeaza</a></li>
			<li><a href="#">cauta </a></li>
		</ul>
	</div>

	
///////content
<div class="title">Titlu</div>
				
		<!-- de sters-->
				
<form>
					
<table width="100%" border="0" cellpadding="1" cellspacing="1" style="border:1px solid #CCCCCC;">
  <tr align="center" bgcolor="#ece9d8">
    <td>Facultate</td>
    <td>Tip</td>
    <td>Disciplina</td>
    <td>Forma</td>
    <td>Cod</td>
    <td>An</td>
    <td>Serie</td>
    <td>Nr Studenti  </td>
    <td>Nr Grupe </td>
    <td>Tip Grupa  </td>
    <td>C1</td>
    <td>A1</td>
    <td>Tip</td>
    <td>Post</td>
    <td>Grad</td>
    <td>Norma</td>
    <td>Ocupat</td>
    <td>Acoperit</td>
    <td>Efectiv</td>
    <td>An/Gr</td>
    <td>Zi</td>
    <td>Ora </td>
    <td>Sala</td>
    </tr>
  <tr bgcolor="#f6f2d8">
    <td height="17" width="75pt" align="center"><input type="text" id="in_1" class="form1" value="A&C" onfocus="javascript:this.setAttribute('class','selected');" onblur="javascript:this.setAttribute('class','form1');" style="width:75pt;"/></td>
    <td align="center"><input type="text" class="form1" value="C" style="max-width:20pt;"/></td>
    <td align="left"><input type="text" class="form1" value="Sisteme de operare" /></td>
    <td align="left">IZ</td>
    <td align="left">LR</td>
    <td align="left">&nbsp;</td>
    <td align="center" sdval="4" sdnum="1033;0;0">4</td>
    <td align="left">CA</td>
    <td align="right" sdval="150" sdnum="1033;">&nbsp;</td>
    <td align="right" sdval="150" sdnum="1033;">150</td>
    <td align="center" sdval="6" sdnum="1033;">6</td>
    <td align="center">g</td>
    <td align="center">&nbsp;</td>
    <td align="right" sdval="3" sdnum="1033;">3</td>
    <td align="right"><strong><br />
    </strong></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>
  <tr bgcolor="#ede7c2">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>
</table>
</form>